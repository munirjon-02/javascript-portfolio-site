/*!
 * Assignment 10: Employee List
 * Name: mazimov
 * Date: 08-15-2025
 * Description: This script fetches and displays employee data from an API
 */

"use strict";

$(document).ready(() => {
    // Base URL for employee API
    const baseUrl = 'https://www.mccinfo.net/epsample/employees';
    
    // DOM elements for employee list and info display
    const employeeList = document.getElementById('employeeList');
    const employeeInfo = document.getElementById('employeeInfo');
    
    // Hide error holder initially
    $('#errorHolder').hide();

    // Click handler for Get Employees button
    $('#getEmployees').click((evt) => {
        // Hide UI elements during loading
        $('#loadingHolder').hide();
        $('#employeeList').hide();
        $(evt.target).parent().slideUp();
        
        // Show loading indicator
        $('#loadingHolder').slideDown();
        
        // Fetch employee data from API
        fetch(baseUrl)
            .then(response => response.json())
            .then((employees) => {
                // Process each employee in the response
                for(let employee of employees) {
                    let div = document.createElement('div');
                    let a = document.createElement('a');
                    
                    // Create clickable employee name
                    a.href='#';
                    a.id = employee.id;
                    a.innerHTML = `${employee.first_name} ${employee.last_name}`;
                    a.addEventListener('click', onEmployeeClicked);
                    
                    // Add to DOM
                    div.appendChild(a);
                    employeeList.appendChild(div);
                }
                
                // Hide loading and show employee list
                $('#loadingHolder').fadeOut(400, () => {
                    $('#employeeList').fadeIn();
                });
            })
            .catch((e) => {
                console.log(e.message);
                $('#errorHolder').show().html('Error loading employees');
            });
    });

    // Handler for when an employee name is clicked
    const onEmployeeClicked = (e) => {
        // Clear any previous errors or info
        $('#errorHolder').hide();
        $('#errorHolder').html(' ');
        employeeInfo.innerHTML = '';
        
        // Fetch details for specific employee
        fetch(`${baseUrl}/${e.currentTarget.id}`)
            .then(response => response.json())
            .then((employee) => {
                // Create employee detail elements
                let div = document.createElement('div');
                let img = document.createElement('img');
                img.src = employee.image_filename;
                img.alt = `${employee.first_name} ${employee.last_name}`;
                
                let h1 = document.createElement('h1');
                h1.innerText = `${employee.first_name} ${employee.last_name}`;
                
                let divDepartment = document.createElement('div');
                divDepartment.innerText = `Department: ${employee.department.name}`;
                
                let divSalary = document.createElement('div');
                // Format salary using accounting.js
                divSalary.innerText = `Annual Salary: ${accounting.formatMoney(employee.annual_salary, {
                    symbol: "$",
                    decimal: ".",
                    thousand: ",",
                    precision: 2,
                    format: "%s%v"
                })}`;
                
                let divHireDate = document.createElement('div');
                divHireDate.innerText = `Hire Date: ${employee.hire_date}`;
                
                // Build DOM structure
                div.appendChild(img);
                div.appendChild(h1);
                div.appendChild(divDepartment);
                div.appendChild(divSalary);
                div.appendChild(divHireDate);
                
                // Display employee info
                employeeInfo.appendChild(div);
            })
            .catch((e) => {
                console.log(e.message);
                $('#errorHolder').show().html('Error loading employee details');
            });
    }
});