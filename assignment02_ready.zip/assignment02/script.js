/* 
  Author: Munirjon
  Date: 07-18-2025
  File Name: script.js
  Description: Rocket weight calculator that determines if a rocket is light enough to launch.
*/
"use strict";

// Declare variables using let or const
const cargoWeight = [];
const maxWeightLbs = 1000;
let totalCargoWeight = 0;
let itemWeight = 0;
let average = 0;

// Use do-while loop to accept weights until -1 is entered
do {
    itemWeight = parseFloat(prompt("Please enter the item weight in pounds, or input -1 to exit."));

    if (!isNaN(itemWeight)) {
        if(itemWeight >= 0) {
            cargoWeight.push(itemWeight); // Add weight to the array
        } else if (itemWeight !== -1) {
            alert("Item weight must be a valid number that is greater than zero pounds!");
        }
    } else {
        alert("Please enter a valid number.");
    }

} while(itemWeight !== -1);

// Calculate total and average weights
if (cargoWeight.length > 0) {
    for (const weight of cargoWeight) {
        totalCargoWeight += weight;
    }
    average = totalCargoWeight / cargoWeight.length;
}

// Commented-out alert message
// alert("Total cargo weight is " + totalCargoWeight + "; average item weight is " + average);

// Create HTML using template literal
const html = `
    <h1>Rocket Weight Summary</h1>
    <p>Total cargo weight: ${totalCargoWeight.toFixed(2)}</p>
    <p>Average item weight: ${average.toFixed(2)}</p>
    <p>${totalCargoWeight < maxWeightLbs ? "Congratulations! The rocket can take off!" : 
        "Oh no! Your rocket is too heavy to take off!<p>The rocket must be less than 1000 pounds to take off!</p>"}</p>
`;

// Output the HTML to the document
document.write(html);

/*
  This script calculates whether a rocket can launch based on total cargo weight.
  It uses a loop to gather item weights until the user enters -1.
  It displays the total and average weights, and a final message depending on if the rocket is too heavy.
*/
