/**
 * script.js - Main application logic for Weatherator
 * 
 * This script handles weather data fetching and UI interactions.
 * 
 * @file This file contains the main application logic.
 * @author Your Name
 * @version 1.0.0
 */

"use strict";

document.addEventListener('DOMContentLoaded', () => {
    (function() {
        // Initialize clock
        Clock.startClock();
        
        // Weather data variables
        let lat;
        let lon; 
        const appId = '6ae9e4516899cbbe9c1a98da589136a5';
        const currentWxHolder = document.getElementById('currentWxHolder');
        const fiveDayInfoHolder = document.getElementById('fiveDayInfoHolder');

        // Set up button event listeners
        const buttons = document.getElementsByTagName('button');
        for(let button of buttons) {
            button.addEventListener('click', onButtonClicked);
        }
      
        // Get user's current position
        navigator.geolocation.getCurrentPosition((pos) => {
            lat = pos.coords.latitude;
            lon = pos.coords.longitude;
        });

        /**
         * Handles button click events
         * @param {Event} evt - The click event object
         */
        function onButtonClicked(evt) {
            const buttonName = evt.target.dataset.id;
            switch(buttonName) {
                case 'getCurrentWx':
                    getCurrentWx();
                    break;
                case 'getFiveDay':
                    getFiveDay();
                    break;
            }
        }

        /**
         * Fetches and displays current weather data
         */
        function getCurrentWx() {
            const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${appId}&units=imperial`;

            fetch(url)
            .then((r) => r.json())
                .then((wx) => {
                    console.log(wx);
                    const locationName = wx.name;
                    const currentTemp = wx.main.temp;
                    const maxTemp = wx.main.temp;
                    const humidity = wx.main.humidity;

                    let s = `
                        <h2>${locationName}</h2>
                        <div>Current Temp: ${currentTemp}&#8457;</div>
                        <div>Max Temp: ${maxTemp}&#8457;</div>
                        <div>Humidity: ${humidity}%</div>
                    `;

                    currentWxHolder.innerHTML = s;
                })
                .catch((e) => {
                    console.log(e);
                });
        }
        
        /**
         * Fetches and displays 3-hour forecast data
         */
        function getFiveDay() {
            const url = `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&cnt=5&appid=${appId}&units=imperial`;
            fetch(url)
                .then((r) => r.json())
                .then((wx) => {
                    console.log(wx);
                    const locationName = wx.city.name;
                    const population = wx.city.population;
                    const f = wx.list;
                    const forecastArray = [];

                    for (let i = 0; i <= 2; i++) {
                        console.log(f[i]);
                        let w = new WeatherForecast(f[i].dt_txt, f[i].main.temp, f[i].main.temp_min, f[i].main.temp_max);
                        forecastArray.push(w);
                    }

                    let h2 = document.createElement('h2');
                    let h3 = document.createElement('h3');
                    h2.innerHTML = locationName;
                    h3.innerHTML = '3 Hour Forecast';
                    fiveDayInfoHolder.appendChild(h2);
                    fiveDayInfoHolder.appendChild(h3);

                    for(let forecast of forecastArray) {
                        let div = document.createElement('div');
                        let h4 = document.createElement('h3');
                        h4.innerHTML = forecast.getDayString();
                        div.appendChild(h4);

                        let d = document.createElement('div');
                        d.innerHTML = 'Forecast Time (UTC): ' + forecast.getDate().getHours() + " hrs.";
                        div.appendChild(d);

                        d = document.createElement('div');
                        d.innerHTML = 'Temperature: ' + forecast.getTemp() + '&#8457;';
                        div.appendChild(d);

                        d = document.createElement('div');
                        d.innerHTML = 'Max Temperature: ' + forecast.getMaxTemp() + '&#8457;';
                        div.appendChild(d);

                        d = document.createElement('div');
                        d.innerHTML = 'Min Temperature: ' + forecast.getMinTemp() + '&#8457;';
                        div.appendChild(d);

                        let hr = document.createElement('hr');
                        div.appendChild(hr);

                        fiveDayInfoHolder.append(div);
                    }
                })
                .catch((e) => {
                    console.log(e);
                });
        }
    })();
});