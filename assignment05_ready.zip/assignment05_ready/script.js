/* 
 * Food Service Survey Form Handler
 * Filename: script.js
 * Author: mazimov
 * Date: 08-15-2025
 * This script handles form validation and submission for a food service survey.
 * It validates user input, displays error messages, and processes form submission.
 */

"use strict";

$(document).ready(() => {
    // Set focus to first text box when document loads
    $('#firstName').focus();

    // Handle form submission
    $('#submitButton').click((e) => {
        // Trim all input values and update the fields
        const firstName = $('#firstName').val().trim();
        $('#firstName').val(firstName);
        
        const age = $('#age').val().trim();
        $('#age').val(age);
        
        const mealName = $('#mealName').val().trim();
        $('#mealName').val(mealName);
        
        const mealHolder = $('input[name="meal"]:checked').val();
        const mealRating = $('input[name="rating"]:checked').val();
        
        let error = false;

        // Clear all previous error messages
        $('.error-message').text('');

        // Validate first name (required)
        if (firstName === "") {
            $('#firstNameHolder .error-message').text("First name is required!");
            error = true;
        }

        // Validate age (required, numeric, positive)
        if (age === "") {
            $('#ageHolder .error-message').text("Age is required!");
            error = true;
        } else if (isNaN(age)) {
            $('#ageHolder .error-message').text("Age must be a number!");
            error = true;
        } else if (age < 0) {
            $('#ageHolder .error-message').text("Age must be positive!");
            error = true;
        }

        // Validate meal name (required)
        if (mealName === "") {
            $('#mealNameHolder .error-message').text("Meal name is required!");
            error = true;
        }

        // Validate meal selection (required)
        if (!mealHolder) {
            $('#mealHolder .error-message').text("Meal selection is required!");
            error = true;
        }

        // Validate rating selection (required)
        if (!mealRating) {
            $('#mealRatingHolder .error-message').text("Meal rating is required!");
            error = true;
        }

        // If errors exist, prevent form submission
        if (error) {
            e.preventDefault();
        } else {
            // For debugging: show collected form data before submission
            console.log("Form data:", {
                firstName: firstName,
                age: age,
                mealName: mealName,
                meal: mealHolder,
                rating: mealRating
            });
        }
    });

    // Handle reset button click
    $('#resetButton').click(() => {
        // Clear all error messages
        $('.error-message').text('');
        
        // Move focus to first text box
        $('#firstName').focus();
    });
});