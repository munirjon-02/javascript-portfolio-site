/*
 * Temperature and Length Conversion Application
 * Filename: convert_temp.js
 * Author: mazimov
 * Date: 08-15-2025
 * Description: An application that converts between temperature units (Celsius/Fahrenheit)
 *              and length units (Feet/Meters) with error handling and user feedback.
 */

"use strict";

/*********************
*  helper functions  *
**********************/
const $ = selector => document.querySelector(selector);

// Temperature conversion functions (preserved as requested)
const calculateCelsius = temp => (temp-32) * 5/9;
const calculateFahrenheit = temp => temp * 9/5 + 32;

// Length conversion functions
const calculateMeters = feet => feet / 3.2808;
const calculateFeet = meters => meters * 3.2808;

/**
 * Toggles display labels and clears previous values
 * @param {string} label1Text - Text for the first label
 * @param {string} label2Text - Text for the second label
 */
const toggleDisplay = (label1Text, label2Text) => {
    // Update the labels
    $("#label_1").textContent = label1Text;
    $("#label_2").textContent = label2Text;
    
    // Clear computed value and any messages
    $("#value_computed").value = "";
    $("#message").textContent = "";
    
    // Select the input field for new entry
    $("#value_entered").select();
    
    console.log(`Display toggled to: ${label1Text} → ${label2Text}`);
};

/****************************
*  event handler functions  *
*****************************/
const performConversion = () => {
    const inputValue = parseFloat($("#value_entered").value);
    const messageDiv = $("#message");
    const computedField = $("#value_computed");
    
    // Clear previous results and messages
    computedField.value = "";
    messageDiv.textContent = "";
    
    // Validate input
    if (isNaN(inputValue)) {
        messageDiv.textContent = "Please enter a valid number";
        $("#value_entered").value = "";
        $("#value_entered").select();
        return;
    }
    
    // Determine conversion type and perform calculation
    let result;
    if ($("#to_celsius").checked) {
        result = calculateCelsius(inputValue);
    } else if ($("#to_fahrenheit").checked) {
        result = calculateFahrenheit(inputValue);
    } else if ($("#to_meters").checked) {
        result = calculateMeters(inputValue);
    } else if ($("#to_feet").checked) {
        result = calculateFeet(inputValue);
    }
    
    // Display result with 2 decimal places
    computedField.value = result.toFixed(2);
    $("#value_entered").select();
    
    console.log(`Converted ${inputValue} to ${computedField.value}`);
};

// Temperature toggle handlers
const toggleToCelsius = () => toggleDisplay("Enter F degrees:", "Degrees Celsius:");
const toggleToFahrenheit = () => toggleDisplay("Enter C degrees:", "Degrees Fahrenheit:");

// Length toggle handlers
const toggleToMeters = () => toggleDisplay("Enter Feet:", "Meters:");
const toggleToFeet = () => toggleDisplay("Enter Meters:", "Feet:");

document.addEventListener("DOMContentLoaded", () => {
    // Add event handlers for buttons
    $("#convert").addEventListener("click", performConversion);
    
    // Add event handlers for temperature radio buttons
    $("#to_celsius").addEventListener("click", toggleToCelsius);
    $("#to_fahrenheit").addEventListener("click", toggleToFahrenheit);
    
    // Add event handlers for length radio buttons
    $("#to_meters").addEventListener("click", toggleToMeters);
    $("#to_feet").addEventListener("click", toggleToFeet);
    
    // Set default focus
    $("#value_entered").focus();
});