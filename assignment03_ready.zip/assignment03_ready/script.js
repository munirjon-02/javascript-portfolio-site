/*---------------------------------------------------------
 * Assignment 3: Tax Calculator
 * Student: Munirjon
 * Date: 07-23-2025
 * Description: This script calculates taxes based on monthly salary input.
 *-------------------------------------------------------*/

"use strict";

//DO NOT MODIFY THIS CODE
function calculateTax(subtotal, taxRate) {
    const tax = parseFloat(subtotal * taxRate);
    return tax.toFixed(2);
}

function print(grossWages, federalTax, stateTax, ssTax, medicareTax, netWages) {
    const msg = `
                Gross wages: $${grossWages.toFixed(2)}

                Deductions:
                --------------------------------
                Federal Taxes:   $${federalTax.toFixed(2)}
                State Taxes:     $${stateTax.toFixed(2)}
                Social Security: $${ssTax.toFixed(2)}
                Medicare:        $${medicareTax.toFixed(2)}

                Net wages: $${netWages.toFixed(2)}
    `;
    alert(msg);
}
//END DO NOT MODIFY THIS CODE
//YOUR CODE GOES BELOW

/*  Terminology
    --------------
    Here are some terms, in case you don't understand gross/net wages.

    Gross wages is your full pay, before deductions.

    Net wages is what you actually receive, once taxes, insurance, retirement, etc. have been deducted.
*/

// Arrow function that acts as a shorthand for document.querySelector
const $ = (selector) => document.querySelector(selector);

// Wait for DOM to be fully loaded before executing JavaScript
document.addEventListener('DOMContentLoaded', () => {
    // Add click event handler to the calculate button
    $('#calculateTaxes').addEventListener('click', () => {
        // Get the monthly salary value from input field and convert to number
        const monthlySalary = parseFloat($('#monthlySalary').value);
        
        // Calculate all taxes using the provided calculateTax function
        const federalTax = parseFloat(calculateTax(monthlySalary, 0.12));
        const stateTax = parseFloat(calculateTax(monthlySalary, 0.05));
        const ssTax = parseFloat(calculateTax(monthlySalary, 0.06));
        const medicareTax = parseFloat(calculateTax(monthlySalary, 0.015));
        
        // Calculate net wages by subtracting all taxes from gross wages
        const netWages = monthlySalary - federalTax - stateTax - ssTax - medicareTax;
        
        // Call the print function with all calculated values
        print(monthlySalary, federalTax, stateTax, ssTax, medicareTax, netWages);
    });
});