/*
 * Metroficator Conversion Tool
 * Filename: script.js
 * Author: mazimov
 * Date: 08-15-2025
 * Handles unit conversions between various measurement systems
 */

"use strict";

// This is a helper function to convert a string to a numeric value
// Returns: An integer or a float value of the string
// Throws: Error if the string is not a number
function convertToNumber(numVal) {
    if(!isNaN(numVal)) {
        if(Number.isInteger(parseFloat(numVal))) {
            return parseInt(numVal);
        } else {
            return parseFloat(numVal);
        }
    } else {
        throw new Error("The value entered is not a numeric value!");
    }
}

$(document).ready(() => {
    let valueToConvert = 0;
    const valueHolder = $('#valueHolder');
    const convertButton = $('#convertButton');
    
    // Reset function to clear the input field
    function reset() {
        valueHolder.val(0);
    }

    convertButton.on('click', () => {
        try {
            const selectedOptionValue = $('#conversionSelector').val();
            
            valueToConvert = valueHolder.val();
            valueToConvert = convertToNumber(valueToConvert);

            if(valueToConvert < 0 && !selectedOptionValue.includes('c2f') && !selectedOptionValue.includes('f2c')) {
                alert("Error: Value to convert cannot be less than zero!");
                return;
            } else if(valueToConvert === 0 && !selectedOptionValue.includes('c2f') && !selectedOptionValue.includes('f2c')) {
                alert("Error: Value to convert must be greater than zero!");
                reset();
                return;
            }
            
            //BEGIN SWITCH
            let result = 0;
            let fromUnit = '';
            let toUnit = '';
            
            switch(selectedOptionValue) {
                case 'm2k':  // Miles to Kilometers
                    result = (valueToConvert * 1.609344).toFixed(2);
                    fromUnit = 'miles';
                    toUnit = 'kilometers';
                    break;
                case 'k2m':  // Kilometers to Miles
                    result = (valueToConvert * 0.62137).toFixed(2);
                    fromUnit = 'kilometers';
                    toUnit = 'miles';
                    break;
                case 'p2k':  // Pounds to Kilograms
                    result = (valueToConvert * 0.45359237).toFixed(2);
                    fromUnit = 'pounds';
                    toUnit = 'kilograms';
                    break;
                case 'k2p':  // Kilograms to Pounds
                    result = (valueToConvert / 0.45359237).toFixed(2);
                    fromUnit = 'kilograms';
                    toUnit = 'pounds';
                    break;
                case 'f2m':  // Feet to Meters
                    result = (valueToConvert * 0.3048).toFixed(2);
                    fromUnit = 'feet';
                    toUnit = 'meters';
                    break;
                case 'm2f':  // Meters to Feet
                    result = (valueToConvert / 0.3048).toFixed(2);
                    fromUnit = 'meters';
                    toUnit = 'feet';
                    break;
                case 'f2c':  // Fahrenheit to Celsius
                    result = ((valueToConvert - 32) / 1.8).toFixed(2);
                    fromUnit = 'Fahrenheit';
                    toUnit = 'Celsius';
                    break;
                case 'c2f':  // Celsius to Fahrenheit
                    result = ((valueToConvert * 1.8) + 32).toFixed(2);
                    fromUnit = 'Celsius';
                    toUnit = 'Fahrenheit';
                    break;
                default:
                    throw new Error("Invalid conversion option selected");
            }
            
            alert(`${valueToConvert} ${fromUnit} equals ${result} ${toUnit}`);
            //END SWITCH
            
        } catch(error) {
            alert(error.message);
            reset();
            return;
        }
    });
    
    // Example ternary operator replacement
    const someCondition = true;
    const result = someCondition ? 'Condition is true' : 'Condition is false';
});