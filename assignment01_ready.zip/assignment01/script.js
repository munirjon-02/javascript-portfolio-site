/*
  Name: Munirjon
  File: script.js
  Date: 07-18-2025
  Description: This script converts weight, height, and temperature from imperial to metric units.
  Assignment: Module 1 Assignment
*/

"use strict";

// Prompt the user and parse decimal values
let lbs = parseFloat(prompt("Please enter your weight in pounds."));
let inches = parseFloat(prompt("Please enter your height in inches"));
let fahrenheit = parseFloat(prompt("Please enter the current temperature in Fahrenheit"));

// Conversion formulas
const KILOGRAMS_PER_POUND = 0.45359237;
const CENTIMETERS_PER_INCH = 2.54;
const CELSIUS_FORMULA = 5 / 9;

// Perform conversions and round to 2 decimal places
let kg = (lbs * KILOGRAMS_PER_POUND).toFixed(2);
let cm = (inches * CENTIMETERS_PER_INCH).toFixed(2);
let celsius = ((fahrenheit - 32) * CELSIUS_FORMULA).toFixed(2);

// Build HTML output using template literals
const html = `
  <h1>The Metroficator</h1>  
  <p>${lbs} pounds equals ${kg} kg</p>
  <p>${inches} inches equals ${cm} cm</p>
  <p>${fahrenheit} F equals ${celsius} C</p>
`;

// Display the result in the document
document.write(html);

/*
  Explanation:
  This program asks the user for weight, height, and temperature,
  converts the values to metric units using known conversion constants,
  and displays them formatted to two decimal places. Constants are used
  where values don’t change, and "use strict" helps enforce clean, safe coding.
*/